# LittleSteps v1.1 — Mobile release candidate

This is a fully playable **offline learning game**, not a signed store binary. Run `www/index.html` in a browser for a quick preview. No AI, network calls, ads, account login, or payments are present.

## What works
- Four quiz adventures: colours, numbers, shapes and animals, five questions each.
- Reward stars, gentle retry, optional spoken questions using Web Speech synthesis if supported.
- Local storage of stars and correct-answer counts.
- Grown-up check before opening parent progress and reset controls.

## Setup
Install Node.js (currently supported LTS), Android Studio for Android, and on macOS Xcode for iOS.

```bash
npm install
npx cap add android
npx cap add ios  # requires macOS/Xcode
npx cap sync
npx cap open android
npx cap open ios  # requires macOS/Xcode
```

Set your own unique bundle ID in capacitor.config.json **before** adding native projects. Use Android Studio / Xcode to set app icons, signing, versions, build artifacts, target SDK and distribution credentials. Re-run `npx cap sync` after changing www/ files.

## Mandatory before store submission
1. Test all activities and reset on actual Android/iOS phones including offline behaviour and speech support. Confirm screen reader support, no accidental navigation, proper state across restart.
2. Replace all operator/contact placeholders in PRIVACY_POLICY_TEMPLATE.md; publish a public privacy policy URL and add it to store listings and in-app grown-up area as required by marketplaces. The local in-app text is a summary, not a public policy URL.
3. Replace `au.com.yourbrand.littlesteps` with a unique ID you control. Check name and trademarks. Prepare production icon and real screenshots.
4. Complete Apple Kids Category and Google Play Families/Data Safety declarations and comply with age/privacy rules. Obtain appropriate developer account, signing, tax and payment settings. Review privacy impact of native SDKs.
5. Run TestFlight / Play internal and applicable closed testing; create signed `.ipa` / `.aab` builds and submit for review. No approval is guaranteed.
6. Parent gate is only a light arithmetic deterrent; assess stronger age-appropriate parental gate behaviour through device testing/review.

## Business approach
Start free and ad-free. Any later purchase or subscription must live behind appropriate parental controls and use store billing according to platform rules. Do not add behavioural advertising to a children’s app.
