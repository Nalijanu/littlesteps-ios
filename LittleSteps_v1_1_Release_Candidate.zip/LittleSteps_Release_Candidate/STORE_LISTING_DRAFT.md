# LittleSteps — Learn & Play

**Category:** Kids / Education (subject to marketplace approval)
**Age band to consider:** Ages 5 and under (verify content and store answers)
**Short description:** Learn colours, numbers, shapes and animals through gentle games.

## Description
LittleSteps brings four playful learning adventures together in one friendly app. Children can practise identifying colours and shapes, counting everyday objects and recognising animal sounds. Earn stars for correct answers and try again without penalties. Optional read-aloud support helps early learners explore activities with a grown-up. Parents can view progress and reset it within a separate grown-up area.

• No in-app ads or purchases
• No sign-up or account
• Plays offline
• Locally saved stars and activity progress

## Assets still needed
Production icon (1024x1024); store-specific screenshots from real devices; support contact; published privacy URL; final age-rating and data-safety disclosures; check trademark/name availability.
