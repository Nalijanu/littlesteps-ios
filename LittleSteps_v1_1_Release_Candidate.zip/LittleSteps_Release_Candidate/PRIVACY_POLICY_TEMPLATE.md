# LittleSteps privacy policy — publication draft

**Important:** Replace the operator/contact placeholders, publish the page at a stable public HTTPS URL, and verify the following statements still match the final app and any installed SDKs before submitting.

Effective date: [ADD DATE]
Operator: [YOUR NAME OR BUSINESS]
Contact: [YOUR CONTACT EMAIL]

LittleSteps is an offline educational game for young children. It does not require an account and does not request a child’s name, email, location, photographs, or contact information. It contains no advertising, external links in the children’s experience, or third-party analytics. It does not send player scores or learning progress to the operator. Stars and learning progress are stored locally on the device. You may delete this data from the app’s grown-up area or by uninstalling the app / clearing app storage. Optional read-aloud uses supported on-device/browser speech functionality; the app itself does not send speech or microphone recordings to our servers. We do not sell personal information. Questions about this policy can be directed to the operator at the contact listed above.

Please review this policy again if cloud sync, purchases, analytics or additional native SDKs are added.
